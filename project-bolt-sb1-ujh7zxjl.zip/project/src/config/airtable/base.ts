export const AIRTABLE_BASE_CONFIG = {
  apiKey: 'patXMyvil2Kmcy0OX.589625e529308774252f71fcdcd9bb3ca014cc06cd8c96a87f7a19f26c6920ab',
  baseId: 'appcTkkgzPv0ikZ1g',
  webhookUrl: 'https://hook.eu2.make.com/l4cxfvtn1mwt5unyjhs0oil9ave64sdq'
};